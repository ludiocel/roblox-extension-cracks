$(RPlus.style.syncPremiumClass);
