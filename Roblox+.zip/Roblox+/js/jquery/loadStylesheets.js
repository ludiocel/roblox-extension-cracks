﻿(function () {
	RPlus.style.init();
	RPlus.style.loadStylesheet(chrome.extension.getURL("/css/output/themes/dark-theme.css"));
	RPlus.style.loadStylesheet(chrome.extension.getURL("/css/rplus/images.css"));
	RPlus.style.loadStylesheet(chrome.extension.getURL("/css/customIcon.css"));
})();

// WebGL3D
